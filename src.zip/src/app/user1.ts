export class user1_class{
  constructor(
  public name:string,
  public age:number,
  public country:string,
  ){
}
}
