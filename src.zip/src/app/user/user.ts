export class user_class{
  constructor(
   public name:string,
  public age:number,
  public country :string,
  public _id?:string,
  ){
}
}
